#Thu Oct 31 06:09:11 GMT 2019
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.connectionmanager_1.1-javadoc.zip=0c95c1b45ddddfbfdce5a04bab1b6c85
lib/features/com.ibm.websphere.appserver.connectionManagement-1.0.mf=020514996a840e4614f14dec88bad66f
dev/api/ibm/com.ibm.websphere.appserver.api.connectionmanager_1.1.34.jar=f9cb54337837b1a4b470def376e4a362
lib/com.ibm.ws.jca.cm_1.0.34.jar=b590011f74517f64409565ec012d4745
