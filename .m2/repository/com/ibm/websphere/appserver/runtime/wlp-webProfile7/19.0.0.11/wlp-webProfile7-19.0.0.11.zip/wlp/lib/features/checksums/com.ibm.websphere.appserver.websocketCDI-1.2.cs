#Thu Oct 31 06:09:09 GMT 2019
lib/features/com.ibm.websphere.appserver.websocketCDI-1.2.mf=aaf3f8296aa379f87388be5033f3ab62
lib/com.ibm.ws.wsoc.cdi.weld_1.0.34.jar=acea911b594bb59d6521916acf9ee0e9
