#Wed Nov 20 06:08:33 GMT 2019
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.wsoc_1.0-javadoc.zip=07ce0c44fa1722bb91f8b1b1226de28c
dev/api/ibm/com.ibm.websphere.appserver.api.wsoc_1.0.35.jar=e0e46731add29afdcd65b5a37d589fb9
dev/api/spec/com.ibm.websphere.javaee.websocket.1.1_1.0.35.jar=f806775925852d0a272a19d2c8c467c6
lib/features/com.ibm.websphere.appserver.websocket-1.1.mf=11e1361ebebb5aeda3c031d530ad11a9
lib/com.ibm.ws.wsoc_1.0.35.jar=edf520884ed884c5f54c492d34fa19e4
lib/com.ibm.ws.wsoc.1.1_1.0.35.jar=8a80ecd709cc2d44aa03e8d7f3051d4e
