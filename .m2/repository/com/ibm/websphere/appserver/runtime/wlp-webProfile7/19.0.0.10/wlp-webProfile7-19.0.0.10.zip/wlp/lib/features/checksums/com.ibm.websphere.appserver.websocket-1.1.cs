#Wed Oct 02 06:05:55 BST 2019
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.wsoc_1.0-javadoc.zip=5e24b5129bcf0c93aba3ee91bcbc2ef9
lib/com.ibm.ws.wsoc.1.1_1.0.33.jar=4741e2fda270053ae3bc337edadf36fe
lib/com.ibm.ws.wsoc_1.0.33.jar=69f6f7e9a2cb95a9e481be3d0c322ddd
lib/features/com.ibm.websphere.appserver.websocket-1.1.mf=d2da58e9aebd3408404b33a3ae8037de
dev/api/ibm/com.ibm.websphere.appserver.api.wsoc_1.0.33.jar=efd73bedc88d83d64a7b13aa71b4d977
dev/api/spec/com.ibm.websphere.javaee.websocket.1.1_1.0.33.jar=6acf4d8b7615ff88cde95710f0e42370
