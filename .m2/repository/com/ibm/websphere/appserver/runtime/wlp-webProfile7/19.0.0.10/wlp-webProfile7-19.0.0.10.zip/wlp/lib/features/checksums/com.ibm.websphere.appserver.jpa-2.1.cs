#Wed Oct 02 06:05:55 BST 2019
lib/com.ibm.ws.jpa.container.eclipselink_1.0.33.jar=6387682b3efc2211052c299e8e72b5c9
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink_1.0.33.jar=e729dbcc160d374712e59c3be03a8880
lib/features/com.ibm.websphere.appserver.jpa-2.1.mf=2a3438b6627bd7d6c63a297769d3ae5a
