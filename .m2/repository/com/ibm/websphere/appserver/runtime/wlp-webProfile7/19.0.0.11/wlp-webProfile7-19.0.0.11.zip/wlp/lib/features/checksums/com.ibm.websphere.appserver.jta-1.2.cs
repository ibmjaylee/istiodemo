#Thu Oct 31 06:09:10 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.transaction.1.2_1.0.34.jar=7e4d0ed7727823f771ef76f15e331259
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=9212691df8f705f9bdaae3f21b60f074
lib/features/com.ibm.websphere.appserver.jta-1.2.mf=8489310b87728bbb56cbbcdfce792090
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.34.jar=dee1c57915ddae646332aa98178e6acc
