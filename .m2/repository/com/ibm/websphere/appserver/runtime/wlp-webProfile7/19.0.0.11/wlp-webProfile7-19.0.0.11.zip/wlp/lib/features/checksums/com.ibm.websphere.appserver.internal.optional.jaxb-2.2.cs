#Thu Oct 31 06:09:11 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.activation.1.1_1.0.34.jar=3bf4282fc59bd352ed1e0715feefcfb2
lib/com.ibm.ws.jaxb.tools.2.2.10_1.0.34.jar=699ef069ea825a464ac695950ca5d5e1
lib/features/com.ibm.websphere.appserver.internal.optional.jaxb-2.2.mf=ab714c2e8957f6c241ea9467a8559c91
lib/com.ibm.ws.org.apache.geronimo.osgi.registry.1.1_1.0.34.jar=0d58056512860e53991d0096680888a0
dev/api/spec/com.ibm.websphere.javaee.jaxb.2.2_1.0.34.jar=b5d8d6bc17b5f79cf5c78406c7fb333b
