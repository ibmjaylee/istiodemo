#Thu Oct 31 06:09:09 GMT 2019
lib/features/com.ibm.websphere.appserver.mpRestClient1.0-cdi1.2.mf=0513d3443a91e615d592af6e114a7897
lib/com.ibm.ws.microprofile.rest.client.cdi_1.0.34.jar=1626a729958f766745561f1f801d025f
