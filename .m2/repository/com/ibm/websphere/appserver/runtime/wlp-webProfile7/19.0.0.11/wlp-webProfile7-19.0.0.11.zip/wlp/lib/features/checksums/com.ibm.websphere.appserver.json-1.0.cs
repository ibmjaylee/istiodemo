#Thu Oct 31 06:09:09 GMT 2019
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.json_1.0-javadoc.zip=f8cee0d653b68ec9e1170e6c8331111e
lib/features/com.ibm.websphere.appserver.json-1.0.mf=828846eaac7b10830eaaa47cd0ad57b3
dev/api/ibm/com.ibm.websphere.appserver.api.json_1.0.34.jar=dca757779748f46e13715941a4a14a29
lib/com.ibm.json4j_1.0.34.jar=ff0941f8136d6164df525eb68248c101
