#Wed Nov 20 06:08:33 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.transaction.1.2_1.0.35.jar=7360ddfb38f158208a761c25456c0c3e
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=2338de372a69aef11986e4e7dc01e691
lib/features/com.ibm.websphere.appserver.jta-1.2.mf=9c1d37cfcbc71742b87bb6b5c680047e
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.35.jar=64b9307d5d11d451ac4c5472155c8565
