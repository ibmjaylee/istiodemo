#Wed Nov 20 06:08:34 GMT 2019
lib/features/com.ibm.websphere.appserver.jaxrs20managedbeans-1.0.mf=2eb068aa91924ebc794fed3a8acbbeb7
lib/com.ibm.ws.jaxrs.2.0.managedbeans_1.0.35.jar=5fbd85f59290f47ce8afad24efcb899a
