#Thu Oct 31 06:09:09 GMT 2019
lib/features/com.ibm.websphere.appserver.optional.jaxb-2.2.mf=ae668de0660895585352b23effe90682
