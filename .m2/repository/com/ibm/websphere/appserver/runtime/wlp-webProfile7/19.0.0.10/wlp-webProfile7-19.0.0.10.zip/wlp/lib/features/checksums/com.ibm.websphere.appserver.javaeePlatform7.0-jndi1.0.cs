#Wed Oct 02 06:05:55 BST 2019
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.33.jar=374a1983c6c67df012285511809865b3
lib/features/com.ibm.websphere.appserver.javaeePlatform7.0-jndi1.0.mf=e66ce68b8be481453a8d1ac06ddac735
