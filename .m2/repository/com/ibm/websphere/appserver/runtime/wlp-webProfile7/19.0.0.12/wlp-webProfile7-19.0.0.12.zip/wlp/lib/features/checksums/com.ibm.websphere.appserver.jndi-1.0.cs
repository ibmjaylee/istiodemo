#Wed Nov 20 06:08:34 GMT 2019
lib/com.ibm.ws.jndi.url.contexts_1.0.35.jar=5637ce8fb8c609c7bb10a3e53148d36b
lib/com.ibm.ws.org.apache.aries.jndi.core_1.1.35.jar=3949971d1d96f0db6c5705ce45c7567b
lib/com.ibm.ws.org.apache.aries.jndi.api_1.1.35.jar=85ab11b9e93a15a6a5bb51b76a2d3e0d
lib/features/com.ibm.websphere.appserver.jndi-1.0.mf=33b3a7109e68672d4a8100437a712542
lib/com.ibm.ws.jndi_1.0.35.jar=d9c8118a4d620b8118ace72cfdc51902
