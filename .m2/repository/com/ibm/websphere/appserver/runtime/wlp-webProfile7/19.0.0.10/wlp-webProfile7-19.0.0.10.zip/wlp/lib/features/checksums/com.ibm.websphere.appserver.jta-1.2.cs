#Wed Oct 02 06:05:55 BST 2019
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=1c7511758a365464cf63518d1c88e835
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.33.jar=52692454ff59f6e14a07e250608b4992
dev/api/spec/com.ibm.websphere.javaee.transaction.1.2_1.0.33.jar=50e210d9f47f25a8e52e115463018c2e
lib/features/com.ibm.websphere.appserver.jta-1.2.mf=eaf40d6adb6607ac89572eb9cbe803b7
