#Thu Oct 31 06:09:11 GMT 2019
lib/com.ibm.ws.injection_1.0.34.jar=91a2bff7980690cdb3567eac3edf17dd
lib/features/com.ibm.websphere.appserver.injection-1.0.mf=f247a7e5c9f9b4995ef69c80865e8d81
