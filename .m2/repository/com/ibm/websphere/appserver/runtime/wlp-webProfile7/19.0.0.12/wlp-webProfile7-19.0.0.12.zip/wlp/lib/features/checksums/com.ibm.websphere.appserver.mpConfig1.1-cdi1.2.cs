#Wed Nov 20 06:08:33 GMT 2019
lib/com.ibm.ws.microprofile.config.1.1.cdi.services_1.0.35.jar=9e4fb37f48a6720a1320010cb20e8738
lib/com.ibm.ws.microprofile.config.1.1.cdi_1.0.35.jar=1f9a628d725979b4c38bb36f4987ff66
lib/features/com.ibm.websphere.appserver.mpConfig1.1-cdi1.2.mf=5ddb39c1886e21ec8d26d80166abaa81
