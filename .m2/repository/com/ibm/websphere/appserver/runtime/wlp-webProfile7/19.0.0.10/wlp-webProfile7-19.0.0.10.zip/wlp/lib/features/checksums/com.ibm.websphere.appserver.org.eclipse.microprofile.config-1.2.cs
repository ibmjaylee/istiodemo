#Wed Oct 02 06:05:54 BST 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.config-1.2.mf=80ed44cc341562b326166fac0bef792a
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.config.1.2.1_1.0.33.jar=f237fd57b7d654a503f639e552055f6b
