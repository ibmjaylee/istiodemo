#Wed Nov 20 06:08:33 GMT 2019
lib/com.ibm.ws.jaxrs.2.0.beanvalidation_1.0.35.jar=9f65808deb6ec7bb470ecae8a877d738
lib/features/com.ibm.websphere.appserver.jaxrsBeanValidation-2.0.mf=f3a1275f965648619ff76f6706f74944
