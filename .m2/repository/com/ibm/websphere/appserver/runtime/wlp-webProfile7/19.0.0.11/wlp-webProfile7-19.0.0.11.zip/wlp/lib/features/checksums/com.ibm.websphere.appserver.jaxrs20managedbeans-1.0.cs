#Thu Oct 31 06:09:11 GMT 2019
lib/features/com.ibm.websphere.appserver.jaxrs20managedbeans-1.0.mf=ad99606c061fabe55cafad87184727f2
lib/com.ibm.ws.jaxrs.2.0.managedbeans_1.0.34.jar=03b91e7f78a5e052599ea23d8fef280f
