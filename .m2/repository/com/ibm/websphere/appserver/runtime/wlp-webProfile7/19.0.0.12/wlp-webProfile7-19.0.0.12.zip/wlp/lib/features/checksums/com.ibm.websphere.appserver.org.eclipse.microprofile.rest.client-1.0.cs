#Wed Nov 20 06:08:33 GMT 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.rest.client.1.0_1.0.35.jar=d000bfb31a15e0730ce915d03b6fef4c
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.rest.client-1.0.mf=a46c8221dcdcef49d3ccaa2c13bbaecf
