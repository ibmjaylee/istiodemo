#Wed Oct 02 06:05:56 BST 2019
dev/api/spec/com.ibm.websphere.javaee.activation.1.1_1.0.33.jar=b316734deaa9957ba406c8ec619b651d
lib/com.ibm.ws.org.apache.geronimo.osgi.registry.1.1_1.0.33.jar=1d6f4dd6a518f4925b068a261feb4ed2
lib/features/com.ibm.websphere.appserver.internal.optional.jaxb-2.2.mf=2b0905eed5ee40dd482c7bdf73e9029c
lib/com.ibm.ws.jaxb.tools.2.2.10_1.0.33.jar=cc83cd7a6b571a75ffe805f557ce1a77
dev/api/spec/com.ibm.websphere.javaee.jaxb.2.2_1.0.33.jar=6eac4a0ba3380122dcc21e0123a4e05e
