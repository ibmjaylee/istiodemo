#Thu Oct 31 06:09:10 GMT 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.config-1.1.mf=b2996e005000a45bc9681488123a9aa6
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.config.1.1_1.2.34.jar=69f93f7978808a169a3cc013c1117c5f
