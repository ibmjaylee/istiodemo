#Wed Nov 20 06:08:32 GMT 2019
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=2338de372a69aef11986e4e7dc01e691
dev/api/spec/com.ibm.websphere.javaee.transaction.1.1_1.0.35.jar=96321f10ec40a51546f455d3fb9a2523
lib/features/com.ibm.websphere.appserver.jta-1.1.mf=d751c62a805ca95274ae73398d9918e5
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.35.jar=64b9307d5d11d451ac4c5472155c8565
