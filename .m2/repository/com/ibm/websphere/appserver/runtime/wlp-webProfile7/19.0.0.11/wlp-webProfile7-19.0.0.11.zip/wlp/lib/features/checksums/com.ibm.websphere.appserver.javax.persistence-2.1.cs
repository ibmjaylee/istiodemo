#Thu Oct 31 06:09:11 GMT 2019
lib/com.ibm.ws.javaee.persistence.api.2.1_1.0.34.jar=90c9d8c61fe54c4436278a8f6b50dc08
dev/api/spec/com.ibm.websphere.javaee.persistence.2.1_1.0.34.jar=df0b1541ec1600c183134daa014900ab
lib/features/com.ibm.websphere.appserver.javax.persistence-2.1.mf=6727218d64b190cab29414151983c4b4
