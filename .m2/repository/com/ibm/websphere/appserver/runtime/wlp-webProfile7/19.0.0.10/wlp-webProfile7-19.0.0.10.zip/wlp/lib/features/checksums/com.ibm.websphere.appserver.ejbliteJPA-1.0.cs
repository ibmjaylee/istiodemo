#Wed Oct 02 06:05:55 BST 2019
lib/com.ibm.ws.ejbcontainer.jpa_1.0.33.jar=1aaff792553a1f7fd30ec59d5850bd9d
lib/features/com.ibm.websphere.appserver.ejbliteJPA-1.0.mf=3fcc2fea0555bffc1613c22a8b528615
