#Wed Nov 20 06:08:34 GMT 2019
lib/com.ibm.ws.require.java8_1.0.35.jar=ab841257c94a379e2ced0c33c437d083
lib/features/com.ibm.websphere.appserver.microProfile-1.3.mf=f258c5f37db1896ea4a37f4de3c0bc0c
