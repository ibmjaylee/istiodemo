#Wed Oct 02 06:05:56 BST 2019
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.connectionpool_1.1-javadoc.zip=37ad5f90fc47d3171fb38e0eb4d644bb
dev/api/ibm/com.ibm.websphere.appserver.api.connectionpool_1.1.33.jar=837c5283570e2f0d1787b35937a3162b
lib/features/com.ibm.websphere.appserver.connectionpoolmonitor-1.0.mf=55c5570042529a5a62fc9b5ad970c8e9
lib/com.ibm.ws.connectionpool.monitor_1.1.33.jar=bf4b8ef258efa98ce2c76ffa28015fe7
