#Wed Oct 02 06:05:55 BST 2019
lib/com.ibm.ws.jpa.container.beanvalidation.1.1_1.0.33.jar=8a353ad386931997768df27680b005aa
lib/features/com.ibm.websphere.appserver.jpa2.0-2.1-bv1.1.mf=8b308c265e252ff16996feee6717b587
