#Wed Nov 20 06:08:33 GMT 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.metrics.1.1.1_1.0.35.jar=9662bf94a68e7af9d7b37dbbc7b831aa
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.metrics-1.1.mf=af1b2657e36736a90a511ec3792cb4d0
