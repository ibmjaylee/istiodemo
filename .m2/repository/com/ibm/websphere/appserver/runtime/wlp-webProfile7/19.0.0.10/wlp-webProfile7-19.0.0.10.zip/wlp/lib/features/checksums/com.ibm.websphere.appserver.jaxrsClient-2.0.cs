#Wed Oct 02 06:05:56 BST 2019
lib/com.ibm.ws.jaxrs.2.0.client_1.0.33.jar=99514b55304cdfc1c640bb8db5476ed9
lib/features/com.ibm.websphere.appserver.jaxrsClient-2.0.mf=9fd63c77e8d3139cc1d71317234b3085
lib/com.ibm.ws.cxf.client_1.0.33.jar=37c4c96fca683e4678e5f2dc6b5a94c3
