#Wed Nov 20 06:08:34 GMT 2019
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.connectionmanager_1.1-javadoc.zip=c21fb4369f9c6bcf2bf8a24aeec06d6b
dev/api/ibm/com.ibm.websphere.appserver.api.connectionmanager_1.1.35.jar=7d68769f88196fab5070833fe6101984
lib/features/com.ibm.websphere.appserver.connectionManagement-1.0.mf=0c574cd64192dbed962e7dbb881bdfe4
lib/com.ibm.ws.jca.cm_1.0.35.jar=2c662239829ab4b9a594c5e44156c741
