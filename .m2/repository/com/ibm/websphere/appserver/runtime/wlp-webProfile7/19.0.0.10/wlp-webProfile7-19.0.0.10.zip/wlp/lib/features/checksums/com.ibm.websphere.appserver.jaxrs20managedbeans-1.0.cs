#Wed Oct 02 06:05:56 BST 2019
lib/features/com.ibm.websphere.appserver.jaxrs20managedbeans-1.0.mf=42ef57c0c594915869fa325ae5ed96bd
lib/com.ibm.ws.jaxrs.2.0.managedbeans_1.0.33.jar=77a4d0f3751ccd276735d96b2a0436ec
