#Thu Oct 31 06:09:10 GMT 2019
lib/com.ibm.ws.jpa.container.beanvalidation.1.1_1.0.34.jar=34dc84c1f36a22d379cfca65ead51fc6
lib/features/com.ibm.websphere.appserver.jpa2.0-2.1-bv1.1.mf=40bbc2c63fd0782a96d03158ec0d7fd7
