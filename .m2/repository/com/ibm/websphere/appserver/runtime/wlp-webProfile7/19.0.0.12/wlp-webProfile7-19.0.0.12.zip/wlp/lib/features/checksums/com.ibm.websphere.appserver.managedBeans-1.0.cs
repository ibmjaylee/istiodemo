#Wed Nov 20 06:08:34 GMT 2019
dev/api/ibm/schema/ibm-managed-bean-bnd_1_0.xsd=3b0b778a121ff7c6c28f9e72afd96488
lib/features/com.ibm.websphere.appserver.managedBeans-1.0.mf=6292a04c604e5419bae54c2e9da0ea4a
dev/api/ibm/schema/ibm-managed-bean-bnd_1_1.xsd=788164a7a6ea3fb24bb6106a48a9068b
lib/com.ibm.ws.managedbeans_1.0.35.jar=737f418ccd950ef8170dc37095d8b3b6
