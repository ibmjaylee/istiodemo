#Thu Oct 31 06:09:11 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.cdi.1.2_1.2.34.jar=2b71fd10299e496a4a7b2391fc759cf2
lib/features/com.ibm.websphere.appserver.javax.cdi-1.2.mf=4f41f822c41276ff6767506a9ade04da
