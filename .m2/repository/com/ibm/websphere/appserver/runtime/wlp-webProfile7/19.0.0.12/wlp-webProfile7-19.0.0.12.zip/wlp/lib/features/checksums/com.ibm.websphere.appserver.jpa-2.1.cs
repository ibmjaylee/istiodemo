#Wed Nov 20 06:08:33 GMT 2019
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink_1.0.35.jar=6d8477e27fbe902222ab0e1f9a33ecaf
lib/com.ibm.ws.jpa.container.eclipselink_1.0.35.jar=c1c0be7b2fe19ad2f7114e778f4b6735
lib/features/com.ibm.websphere.appserver.jpa-2.1.mf=e24e00fc0f9db5dbf6a8a82c03993ccb
