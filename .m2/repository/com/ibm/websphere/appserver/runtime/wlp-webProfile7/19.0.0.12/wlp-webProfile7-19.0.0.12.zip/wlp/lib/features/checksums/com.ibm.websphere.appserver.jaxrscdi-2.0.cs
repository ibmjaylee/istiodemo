#Wed Nov 20 06:08:33 GMT 2019
lib/com.ibm.ws.jaxrs.2.0.cdi_1.0.35.jar=10fc048c962817e1ad646e5dad09c69a
lib/features/com.ibm.websphere.appserver.jaxrscdi-2.0.mf=fab629f71148c58ed90b7f5ecd5a3425
