#Wed Oct 02 06:05:56 BST 2019
dev/api/spec/com.ibm.websphere.javaee.cdi.1.2_1.2.33.jar=f1be31c74a9659ceccd7ee211bf00067
lib/features/com.ibm.websphere.appserver.javax.cdi-1.2.mf=dc68ad4636afb6519950d7ac222e0e6c
