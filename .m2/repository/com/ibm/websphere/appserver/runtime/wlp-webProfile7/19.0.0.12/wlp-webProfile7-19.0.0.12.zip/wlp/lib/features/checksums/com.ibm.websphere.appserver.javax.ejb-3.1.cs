#Wed Nov 20 06:08:34 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.ejb.3.1_1.0.35.jar=0fcf0909d8d7a0bb7c9b1a6cafb4eb99
lib/features/com.ibm.websphere.appserver.javax.ejb-3.1.mf=78bf4536b275423adf4c06f51604e96e
