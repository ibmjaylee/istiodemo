#Wed Nov 20 06:08:32 GMT 2019
dev/spi/ibm/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0.35.jar=345601c60fd932f8d125e5132a41f3a3
lib/com.ibm.websphere.rest.api.discovery_1.0.35.jar=8e96741cba7ecd22b955f921dfa22ba3
lib/features/com.ibm.websphere.appserver.autoRestHandlerApiDiscovery-1.0.mf=02ea121b9be39a1c4ade9a6f30d3497f
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0-javadoc.zip=4091969ab7b5e5b98659449aa52636a8
