#Thu Oct 31 06:09:10 GMT 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.openapi-1.0.mf=0b19d3b492f4dbec490bc332bc4b2ff3
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.openapi.1.0_1.0.34.jar=bbe37e29f2245be2c8ac2b0a1648e94b
