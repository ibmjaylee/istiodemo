#Wed Oct 02 06:05:56 BST 2019
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.connectionmanager_1.1-javadoc.zip=95aa2a99990de0c93782186432e7c6ca
dev/api/ibm/com.ibm.websphere.appserver.api.connectionmanager_1.1.33.jar=0900d4bd33b1aba151fb7087b71e7684
lib/features/com.ibm.websphere.appserver.connectionManagement-1.0.mf=7f19e0e61667995de49361d641f5ae13
lib/com.ibm.ws.jca.cm_1.0.33.jar=8cfb7e920297c9883ee05b7f9329ce49
