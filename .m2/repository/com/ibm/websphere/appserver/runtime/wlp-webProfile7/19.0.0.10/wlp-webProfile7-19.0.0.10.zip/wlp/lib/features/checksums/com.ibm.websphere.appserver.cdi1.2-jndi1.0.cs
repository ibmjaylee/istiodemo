#Wed Oct 02 06:05:55 BST 2019
lib/features/com.ibm.websphere.appserver.cdi1.2-jndi1.0.mf=6a46ae68458f6015a74c662ec352b42f
lib/com.ibm.ws.cdi.jndi_1.0.33.jar=73f91f32911a5efd5a0b4a1de08abc36
