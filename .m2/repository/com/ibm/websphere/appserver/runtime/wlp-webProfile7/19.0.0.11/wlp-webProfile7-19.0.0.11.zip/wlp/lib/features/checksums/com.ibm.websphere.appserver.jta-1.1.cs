#Thu Oct 31 06:09:09 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.transaction.1.1_1.0.34.jar=77c2415e960495d8c789154b42225d25
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=9212691df8f705f9bdaae3f21b60f074
lib/features/com.ibm.websphere.appserver.jta-1.1.mf=becbf7ca1540d2dbfb6443b9627d0b30
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.34.jar=dee1c57915ddae646332aa98178e6acc
