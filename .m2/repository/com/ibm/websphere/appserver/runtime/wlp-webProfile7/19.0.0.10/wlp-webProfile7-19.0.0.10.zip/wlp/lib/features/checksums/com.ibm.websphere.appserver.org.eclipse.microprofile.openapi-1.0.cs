#Wed Oct 02 06:05:55 BST 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.openapi.1.0_1.0.33.jar=a42f817fa81b1686c7be0b429a8e5067
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.openapi-1.0.mf=593a3576eff9dea6c0633db44a2321b6
