#Wed Oct 02 06:05:56 BST 2019
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.mp.client.3.2_1.0.33.jar=2ceedc7e44720f16952ac5bfa39fd944
lib/com.ibm.ws.require.java8_1.0.33.jar=d80dcb873adce521bea71a98b4cc3615
lib/features/com.ibm.websphere.appserver.mpRestClient-1.0.mf=2163f2eb44e0342b6d847cab0e003c9d
