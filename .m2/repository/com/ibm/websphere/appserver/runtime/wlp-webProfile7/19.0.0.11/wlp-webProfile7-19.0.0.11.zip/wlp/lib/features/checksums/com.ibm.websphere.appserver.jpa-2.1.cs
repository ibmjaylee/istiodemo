#Thu Oct 31 06:09:10 GMT 2019
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink_1.0.34.jar=ddd1844075888636fb95bd95cd392cc3
lib/com.ibm.ws.jpa.container.eclipselink_1.0.34.jar=deb9dba030cab832ad7da4315204d5c1
lib/features/com.ibm.websphere.appserver.jpa-2.1.mf=e80553695c28cb516fb4f1e1cc944f76
