#Thu Oct 31 06:09:10 GMT 2019
lib/com.ibm.ws.cdi.jndi_1.0.34.jar=214a9ae215a7d38aa1c69789068d89a2
lib/features/com.ibm.websphere.appserver.cdi1.2-jndi1.0.mf=3ed2bb28552cb773a1955d8ae252735f
