#Wed Nov 20 06:08:32 GMT 2019
lib/features/com.ibm.websphere.appserver.ejbLiteCore-1.0.mf=d7619a6cd3a36c6c17c0d07e737f3ba7
lib/com.ibm.ws.ejbcontainer.session_1.0.35.jar=f405e1b523a4204294cc158e622631f4
