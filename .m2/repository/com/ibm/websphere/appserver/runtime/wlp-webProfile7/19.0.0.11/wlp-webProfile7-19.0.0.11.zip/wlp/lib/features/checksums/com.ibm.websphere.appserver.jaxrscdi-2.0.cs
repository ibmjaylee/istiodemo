#Thu Oct 31 06:09:10 GMT 2019
lib/features/com.ibm.websphere.appserver.jaxrscdi-2.0.mf=16eab73aa72552e6bf16b2a9bebbadb4
lib/com.ibm.ws.jaxrs.2.0.cdi_1.0.34.jar=d386b8c0ba361f03ced95e41d2c0881b
