#Wed Nov 20 06:08:34 GMT 2019
lib/com.ibm.ws.require.java8_1.0.35.jar=ab841257c94a379e2ced0c33c437d083
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.mp.client.3.2_1.0.35.jar=806ab1bd60639d840c20768b8542abaa
lib/features/com.ibm.websphere.appserver.mpRestClient-1.0.mf=50d763832aa6f1901626a84274696d87
