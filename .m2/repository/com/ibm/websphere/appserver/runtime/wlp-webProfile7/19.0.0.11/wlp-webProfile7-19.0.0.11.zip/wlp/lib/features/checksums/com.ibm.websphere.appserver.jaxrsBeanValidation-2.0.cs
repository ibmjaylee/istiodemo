#Thu Oct 31 06:09:10 GMT 2019
lib/com.ibm.ws.jaxrs.2.0.beanvalidation_1.0.34.jar=9795e209680a99abbfb99acc5931edd4
lib/features/com.ibm.websphere.appserver.jaxrsBeanValidation-2.0.mf=2efc9fc676aa6df352de92b782a66ee2
