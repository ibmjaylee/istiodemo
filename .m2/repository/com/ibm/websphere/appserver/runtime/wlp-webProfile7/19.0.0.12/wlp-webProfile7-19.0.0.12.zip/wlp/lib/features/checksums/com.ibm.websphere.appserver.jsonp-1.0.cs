#Wed Nov 20 06:08:34 GMT 2019
lib/features/com.ibm.websphere.appserver.jsonp-1.0.mf=dc79590bc9bc3fb8f62cc567937d59b7
lib/com.ibm.ws.org.glassfish.json.1.0_1.0.35.jar=7e6d9150ac86f73164fd7eb71adaf49a
dev/api/spec/com.ibm.websphere.javaee.jsonp.1.0_1.0.35.jar=586f29401f9ece42b91a733024f158f0
