#Wed Nov 20 06:08:34 GMT 2019
lib/com.ibm.ws.jpa.container_1.0.35.jar=af0c484631e412843f9ad351d850178d
lib/com.ibm.ws.jpa.container.thirdparty_1.0.35.jar=1b9b5b85a19eb172801659b912ce2ff9
lib/features/com.ibm.websphere.appserver.jpaContainer-2.1.mf=04a3d435532969a576b47f05fc7eec88
lib/com.ibm.ws.jpa.container.v21_1.0.35.jar=3a8f477f0817993134706e81dea6a1f9
