#Wed Nov 20 06:08:34 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.ejb.3.2_1.0.35.jar=fc7799ea6626c91d1344a051a351d5b9
lib/features/com.ibm.websphere.appserver.javax.ejb-3.2.mf=314545e2213274b5fc10c6279e976a23
