#Wed Oct 02 06:05:55 BST 2019
lib/com.ibm.ws.security.common.jsonwebkey_1.0.33.jar=a9f65e59eda7441e5e713f1533af4348
dev/api/ibm/com.ibm.websphere.appserver.api.jwt_1.1.33.jar=28157e47e58e570744936c3d29f3aac1
lib/com.ibm.ws.security.jwt_1.0.33.jar=34f8102c9a7a4caed7d3b7a24967312d
lib/com.ibm.ws.org.jose4j_1.0.33.jar=fc4006501677e069b88d3fa8b0982377
lib/com.ibm.ws.security.common_1.0.33.jar=77726ca8423985ee5716ed8ea5364d61
lib/com.ibm.ws.org.slf4j.jdk14.1.7.7_1.0.33.jar=345e3374e9fad4f71d8bb28565120872
lib/com.ibm.ws.org.apache.commons.codec.1.4_1.0.33.jar=f0f0df4256dfdca16d9d6bf09bd700b0
lib/com.ibm.ws.org.slf4j.api.1.7.7_1.0.33.jar=e45ae6b57f0270cd21880c5f3ed45316
lib/com.ibm.ws.com.google.gson.2.2.4_1.0.33.jar=27647b9ef122c50c3398e163b148f7ef
lib/com.ibm.ws.org.apache.httpcomponents_1.0.33.jar=d93c2a6ad8ddd1478ce1fd9e1939bee3
lib/features/com.ibm.websphere.appserver.jwt-1.0.mf=8dfcbeb0bd5787c6305a10c98600d91a
lib/com.ibm.ws.org.apache.commons.logging.1.0.3_1.0.33.jar=a2b845f7a4ec83d5960a00a47a568fb6
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jwt_1.1-javadoc.zip=f1380f913c14cfbe9667346a2d0a6114
lib/com.ibm.json4j_1.0.33.jar=2c87fa7436147bcb7492bfe587c10e76
