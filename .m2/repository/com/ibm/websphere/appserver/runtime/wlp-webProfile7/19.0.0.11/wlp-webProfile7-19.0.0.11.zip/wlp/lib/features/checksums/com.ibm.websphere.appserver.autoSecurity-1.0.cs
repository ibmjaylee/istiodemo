#Thu Oct 31 06:09:10 GMT 2019
lib/features/com.ibm.websphere.appserver.autoSecurity-1.0.mf=5d2cc3d29d9f3aaf960ba535c9d14f81
dev/api/ibm/com.ibm.websphere.appserver.api.security.spnego_1.0.34.jar=7e5e80068e0d8fb790006070fd38ef7c
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.security.spnego_1.0-javadoc.zip=9de0e7c24b824a07c4f9de5c700d9628
