#Thu Oct 31 06:09:09 GMT 2019
lib/com.ibm.websphere.rest.api.discovery_1.0.34.jar=7fc644d42d9f6d683660af6cf4f0cbf7
dev/spi/ibm/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0.34.jar=c0f036de879e89141289d6aa7064a712
lib/features/com.ibm.websphere.appserver.autoRestHandlerApiDiscovery-1.0.mf=48d7760991f97c76357b41e2fe63e27a
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0-javadoc.zip=6c03074430b5772ef16c1122e14d46f7
