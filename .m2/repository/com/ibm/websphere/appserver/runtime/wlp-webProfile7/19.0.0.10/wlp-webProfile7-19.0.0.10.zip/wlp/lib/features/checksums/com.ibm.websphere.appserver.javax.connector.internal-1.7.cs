#Wed Oct 02 06:05:56 BST 2019
dev/api/spec/com.ibm.websphere.javaee.connector.1.7_1.0.33.jar=bc4536380b335537c87a3594c996623c
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.7.mf=64a69b3637a79059b30f39df4c772020
