#Wed Oct 02 06:05:56 BST 2019
lib/com.ibm.ws.require.java8_1.0.33.jar=d80dcb873adce521bea71a98b4cc3615
lib/features/com.ibm.websphere.appserver.microProfile-1.0.mf=eca2202e967dfa5392ddad80408c0f00
