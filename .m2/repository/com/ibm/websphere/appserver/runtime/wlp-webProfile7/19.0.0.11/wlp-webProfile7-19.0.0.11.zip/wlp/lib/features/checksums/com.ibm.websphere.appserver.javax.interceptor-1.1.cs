#Thu Oct 31 06:09:09 GMT 2019
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.1.mf=28511058e7c990b762bc8228828fb618
dev/api/spec/com.ibm.websphere.javaee.interceptor.1.1_1.0.34.jar=1f4afc97f85310cb480b3ea13cb05df6
