#Wed Oct 02 06:05:55 BST 2019
lib/com.ibm.ws.jaxrs.2.0.beanvalidation_1.0.33.jar=8b1cf612be5be8f1ab75177c63552529
lib/features/com.ibm.websphere.appserver.jaxrsBeanValidation-2.0.mf=e6b669f1ffa814ef288b9cc9804480b7
