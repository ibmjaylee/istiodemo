#Thu Oct 31 06:09:10 GMT 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.rest.client.1.0_1.0.34.jar=f6694f7f3bd190b0b4730a4eeeb76257
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.rest.client-1.0.mf=2a7cb667dbc08198a1f4236d3a504bdf
