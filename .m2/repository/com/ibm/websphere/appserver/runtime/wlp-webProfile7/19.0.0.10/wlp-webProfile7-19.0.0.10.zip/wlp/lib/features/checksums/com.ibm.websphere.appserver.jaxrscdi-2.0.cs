#Wed Oct 02 06:05:55 BST 2019
lib/features/com.ibm.websphere.appserver.jaxrscdi-2.0.mf=ca4526e04a2f8d0f0dee6b11d9964256
lib/com.ibm.ws.jaxrs.2.0.cdi_1.0.33.jar=9dbaa34ca2e23f7e88fd3ee1e657afbc
