#Wed Nov 20 06:08:33 GMT 2019
lib/com.ibm.ws.cdi.jndi_1.0.35.jar=0fc8fe5816050ad00ae916d86f24953e
lib/features/com.ibm.websphere.appserver.cdi1.2-jndi1.0.mf=52189e101a961bf611822673ef7024db
