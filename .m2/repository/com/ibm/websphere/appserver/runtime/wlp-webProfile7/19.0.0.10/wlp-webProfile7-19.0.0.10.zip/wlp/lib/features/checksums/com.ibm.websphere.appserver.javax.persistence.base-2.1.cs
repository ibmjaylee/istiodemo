#Wed Oct 02 06:05:55 BST 2019
lib/com.ibm.ws.javaee.persistence.2.1_1.0.33.jar=a14f82c8ee0dca7ac18ca13a2c986201
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.1.mf=4b9c8b69f6832fb9e99917c645fa4c99
