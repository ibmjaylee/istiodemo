#Wed Nov 20 06:08:33 GMT 2019
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.6.mf=4c81ba33f9b2a053b13b5bd3d5057d10
dev/api/spec/com.ibm.websphere.javaee.connector.1.6_1.0.35.jar=2dd01205e7e0d46667f3a5add38dd40f
