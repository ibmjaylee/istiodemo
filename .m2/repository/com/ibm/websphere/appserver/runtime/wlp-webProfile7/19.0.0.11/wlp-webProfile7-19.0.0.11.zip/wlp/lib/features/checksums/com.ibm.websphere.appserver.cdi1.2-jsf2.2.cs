#Thu Oct 31 06:09:11 GMT 2019
lib/com.ibm.ws.cdi.1.2.jsf_1.0.34.jar=bd5be0ea60331571c98584564169af7b
lib/features/com.ibm.websphere.appserver.cdi1.2-jsf2.2.mf=a2d28bbc810300de1e1d6abcbdff55a9
