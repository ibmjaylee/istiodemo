#Thu Oct 31 06:09:11 GMT 2019
lib/features/com.ibm.websphere.appserver.jsonp-1.0.mf=efb68eff65b89e3bfcca011b86032862
lib/com.ibm.ws.org.glassfish.json.1.0_1.0.34.jar=d3a859f7f8152c1365cce594e52876fe
dev/api/spec/com.ibm.websphere.javaee.jsonp.1.0_1.0.34.jar=d1bf04ad26cd4e751ab67cf932838c58
