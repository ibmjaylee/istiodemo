#Wed Oct 02 06:05:56 BST 2019
lib/features/com.ibm.websphere.appserver.jsonp-1.0.mf=2399bfe4c0c4fed9c8e92f6014d780dc
dev/api/spec/com.ibm.websphere.javaee.jsonp.1.0_1.0.33.jar=d437451a7ff082c9a651e39558041859
lib/com.ibm.ws.org.glassfish.json.1.0_1.0.33.jar=dcb7ad560a44c4a53a225b2361e5e873
