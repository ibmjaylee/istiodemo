#Wed Nov 20 06:08:33 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.annotation.1.1_1.0.35.jar=9ab909829b0d2ea912f3cc74ea435928
lib/features/com.ibm.websphere.appserver.javax.annotation-1.1.mf=2fa75529e8d4cc6ef1320c80dd65f6fb
