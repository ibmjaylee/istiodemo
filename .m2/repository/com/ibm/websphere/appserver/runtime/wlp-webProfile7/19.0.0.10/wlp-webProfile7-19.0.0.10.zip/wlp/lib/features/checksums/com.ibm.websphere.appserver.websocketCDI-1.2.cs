#Wed Oct 02 06:05:54 BST 2019
lib/com.ibm.ws.wsoc.cdi.weld_1.0.33.jar=86e90e53d1cf5b6334118f84731f1518
lib/features/com.ibm.websphere.appserver.websocketCDI-1.2.mf=3e756593bbfb5f77f3770863ef984bb6
