#Wed Nov 20 06:08:33 GMT 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.openapi-1.0.mf=bb7283c99086857006661a62ed1a0cc6
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.openapi.1.0_1.0.35.jar=62dffd50e421c637c2e49fbd0e5d8e17
