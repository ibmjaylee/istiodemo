#Wed Nov 20 06:08:33 GMT 2019
lib/features/com.ibm.websphere.appserver.mpMetrics-monitor-1.0.mf=0b069ee19b0d6d958ffff4e7397ef8d1
lib/com.ibm.ws.microprofile.metrics.monitor_1.0.35.jar=c0216a321a29f0f91465c9f8b0702f2c
