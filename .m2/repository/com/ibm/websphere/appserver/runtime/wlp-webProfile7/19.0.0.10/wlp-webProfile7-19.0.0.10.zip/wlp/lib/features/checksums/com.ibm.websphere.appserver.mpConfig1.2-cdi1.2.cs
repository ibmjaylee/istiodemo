#Wed Oct 02 06:05:54 BST 2019
lib/com.ibm.ws.microprofile.config.1.1.cdi_1.0.33.jar=4fb0df376ed942227dd62f31db3b7b6a
lib/com.ibm.ws.microprofile.config.1.2.cdi_1.0.33.jar=1c3ea6dc6472af3326f83395c26296df
lib/features/com.ibm.websphere.appserver.mpConfig1.2-cdi1.2.mf=02ae41e8373fc82e8ef58b7b3d9e7efd
lib/com.ibm.ws.microprofile.config.1.2.cdi.services_1.0.33.jar=7d163ff94acc96138536f65ab956a6cf
