#Wed Nov 20 06:08:33 GMT 2019
lib/com.ibm.ws.jpa.container.v21.cdi_1.0.35.jar=f6dd95f3e8342969216bb4417b54ee84
lib/features/com.ibm.websphere.appserver.jpaContainer-cdi.mf=9d05ff1c892932bfd198ed69fdbd73c6
