#Wed Nov 20 06:08:32 GMT 2019
dev/spi/ibm/com.ibm.websphere.appserver.spi.restHandler_2.0.35.jar=35c9d7d730ad55eb5aef03a0d415248a
lib/features/com.ibm.websphere.appserver.restHandler-1.0.mf=7299482e8905132f7225418a11975c4f
lib/com.ibm.ws.org.joda.time.1.6.2_1.0.35.jar=6149f71efaad4310d51b130759eeba8f
lib/com.ibm.websphere.jsonsupport_1.0.35.jar=3a043bee1d3db3fc28c598cb91f71628
lib/com.ibm.websphere.rest.handler_1.0.35.jar=87b7baa729b0fe7b8ac0fd26b4c9c5fc
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restHandler_2.0-javadoc.zip=22599eeec85c8e7dd1f165bbc442157c
lib/com.ibm.ws.rest.handler_1.0.35.jar=eec3aa9c95467ac669a290e24a1e02ad
