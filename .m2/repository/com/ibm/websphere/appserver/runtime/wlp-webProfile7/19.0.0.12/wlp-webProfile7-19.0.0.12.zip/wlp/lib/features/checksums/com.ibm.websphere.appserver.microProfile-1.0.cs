#Wed Nov 20 06:08:34 GMT 2019
lib/com.ibm.ws.require.java8_1.0.35.jar=ab841257c94a379e2ced0c33c437d083
lib/features/com.ibm.websphere.appserver.microProfile-1.0.mf=e4791456c0ff4dccafec0188276e353a
