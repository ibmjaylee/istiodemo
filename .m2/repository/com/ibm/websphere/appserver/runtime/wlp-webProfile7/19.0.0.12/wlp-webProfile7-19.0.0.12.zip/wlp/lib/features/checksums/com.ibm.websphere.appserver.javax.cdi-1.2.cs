#Wed Nov 20 06:08:34 GMT 2019
lib/features/com.ibm.websphere.appserver.javax.cdi-1.2.mf=53e7454b96c57d30c9db2d75e3a09fae
dev/api/spec/com.ibm.websphere.javaee.cdi.1.2_1.2.35.jar=af2fa2891b6ee98b8382046196da2139
