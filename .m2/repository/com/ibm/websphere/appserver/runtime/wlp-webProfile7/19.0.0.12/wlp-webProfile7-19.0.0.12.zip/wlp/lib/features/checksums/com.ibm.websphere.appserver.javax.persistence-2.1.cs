#Wed Nov 20 06:08:34 GMT 2019
lib/com.ibm.ws.javaee.persistence.api.2.1_1.0.35.jar=c8b748b00e24b84dccb85af2fb7eb99d
dev/api/spec/com.ibm.websphere.javaee.persistence.2.1_1.0.35.jar=9f3a5b7629f3acceb00f233f7f401085
lib/features/com.ibm.websphere.appserver.javax.persistence-2.1.mf=ce2a8de481cebc940fe9e6f3b94917eb
