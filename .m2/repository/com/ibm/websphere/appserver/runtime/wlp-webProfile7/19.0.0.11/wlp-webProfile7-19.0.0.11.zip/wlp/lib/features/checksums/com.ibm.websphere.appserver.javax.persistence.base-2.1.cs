#Thu Oct 31 06:09:10 GMT 2019
lib/com.ibm.ws.javaee.persistence.2.1_1.0.34.jar=6f8e0006ef1c293086ad525f142b8ec4
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.1.mf=95ace664cdb972f082426caa5c4e100a
