#Wed Oct 02 06:05:55 BST 2019
lib/features/com.ibm.websphere.appserver.javax.jaxrs-2.0.mf=527988b702a0b6514911b238a675ca53
dev/api/spec/com.ibm.websphere.javaee.activation.1.1_1.0.33.jar=b316734deaa9957ba406c8ec619b651d
dev/api/spec/com.ibm.websphere.javaee.jaxb.2.2_1.0.33.jar=6eac4a0ba3380122dcc21e0123a4e05e
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs20_1.0.33.jar=9cd3d2126c18006d151d263b8b6d1381
dev/api/spec/com.ibm.websphere.javaee.jaxrs.2.0_1.0.33.jar=ee7ede0d6d8e15aea4d45d81aad48264
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jaxrs20_1.0-javadoc.zip=ffe5d632edf3ebd0b2edb06e4ed80359
