#Thu Oct 31 06:09:10 GMT 2019
lib/com.ibm.ws.ejbcontainer.jpa_1.0.34.jar=528b437e9a2d18ff74f92063aac244ab
lib/features/com.ibm.websphere.appserver.ejbliteJPA-1.0.mf=c89e8be659d6d0b97644b9c9f0cb0cef
