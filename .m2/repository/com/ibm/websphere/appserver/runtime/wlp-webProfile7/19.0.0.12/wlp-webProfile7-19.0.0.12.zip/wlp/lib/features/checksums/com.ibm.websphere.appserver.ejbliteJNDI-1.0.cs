#Wed Nov 20 06:08:32 GMT 2019
lib/features/com.ibm.websphere.appserver.ejbliteJNDI-1.0.mf=9c672c4abe91a3fd59456adcd3302ad4
lib/com.ibm.ws.jndi.ejb_1.0.35.jar=c97b50b87c89b00c5bca54bfde52e2c4
