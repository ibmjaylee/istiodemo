#Wed Oct 02 06:05:54 BST 2019
lib/features/com.ibm.websphere.appserver.mpRestClient1.0-cdi1.2.mf=f0fe533bb3505e9687bf4d03cdaa7e6b
lib/com.ibm.ws.microprofile.rest.client.cdi_1.0.33.jar=93fcc49550c29b5e4221c65eefcf4941
