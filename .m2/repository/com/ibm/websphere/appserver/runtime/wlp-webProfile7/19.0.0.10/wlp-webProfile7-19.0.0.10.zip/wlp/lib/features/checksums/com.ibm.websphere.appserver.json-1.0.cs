#Wed Oct 02 06:05:54 BST 2019
dev/api/ibm/com.ibm.websphere.appserver.api.json_1.0.33.jar=46b883e9c654905436ae659e72a1783f
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.json_1.0-javadoc.zip=b73371281dd4bcce069a378413d8150b
lib/features/com.ibm.websphere.appserver.json-1.0.mf=b3dc3bd19cbf30e2c41c39f41cd192a2
lib/com.ibm.json4j_1.0.33.jar=2c87fa7436147bcb7492bfe587c10e76
