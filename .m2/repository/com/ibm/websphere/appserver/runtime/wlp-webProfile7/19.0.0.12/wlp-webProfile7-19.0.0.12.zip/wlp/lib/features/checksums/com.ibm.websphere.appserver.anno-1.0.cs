#Wed Nov 20 06:08:32 GMT 2019
lib/features/com.ibm.websphere.appserver.anno-1.0.mf=5ba852f649174fa1ea559da49ac3ebfc
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.anno_1.1-javadoc.zip=625931f75efeb9a390694fd059aa13a6
lib/com.ibm.ws.anno_1.1.35.jar=15f42dbc9a0d398e9ceac5048d2bec0b
dev/spi/ibm/com.ibm.websphere.appserver.spi.anno_1.1.35.jar=686ba83c6d7150865e07b52edf0ca7fa
