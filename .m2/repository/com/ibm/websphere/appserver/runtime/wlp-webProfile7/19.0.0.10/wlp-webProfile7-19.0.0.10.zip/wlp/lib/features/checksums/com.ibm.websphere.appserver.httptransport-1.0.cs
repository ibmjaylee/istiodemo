#Wed Oct 02 06:05:56 BST 2019
lib/com.ibm.ws.transport.http_1.0.33.jar=39b276b3b574bbdd11d975131d085e80
lib/features/com.ibm.websphere.appserver.httptransport-1.0.mf=9455b83495d0378943d34dd9fe5bd5eb
dev/spi/ibm/com.ibm.websphere.appserver.spi.httptransport_4.1.33.jar=a240b9f9a96866937cf891043d2c446b
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.httptransport_4.1-javadoc.zip=750488c5d9d4e2a2c8459ee16b4e67c3
