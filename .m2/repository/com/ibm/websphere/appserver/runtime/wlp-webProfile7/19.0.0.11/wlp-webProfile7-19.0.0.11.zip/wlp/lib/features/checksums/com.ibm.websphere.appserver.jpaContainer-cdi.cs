#Thu Oct 31 06:09:10 GMT 2019
lib/com.ibm.ws.jpa.container.v21.cdi_1.0.34.jar=569bc8788c8540739f18adf6b14af62b
lib/features/com.ibm.websphere.appserver.jpaContainer-cdi.mf=4375145c929d01536fb33c66e8e316d9
