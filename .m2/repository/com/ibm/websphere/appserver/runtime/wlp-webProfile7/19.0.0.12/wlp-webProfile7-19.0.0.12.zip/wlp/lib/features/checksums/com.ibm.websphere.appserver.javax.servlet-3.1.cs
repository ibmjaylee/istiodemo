#Wed Nov 20 06:08:33 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.servlet.3.1_1.0.35.jar=7e4de88a3c99e83a5324901d4523de4a
lib/features/com.ibm.websphere.appserver.javax.servlet-3.1.mf=999feda242b10aabb867956ab3d08847
