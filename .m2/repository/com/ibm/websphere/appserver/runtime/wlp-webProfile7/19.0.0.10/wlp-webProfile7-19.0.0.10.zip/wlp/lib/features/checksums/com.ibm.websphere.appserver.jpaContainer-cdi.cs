#Wed Oct 02 06:05:55 BST 2019
lib/com.ibm.ws.jpa.container.v21.cdi_1.0.33.jar=e77867e832d9d034e9c537e1779e77bb
lib/features/com.ibm.websphere.appserver.jpaContainer-cdi.mf=b975dba8da769da3858bb4dd6f0ee48e
