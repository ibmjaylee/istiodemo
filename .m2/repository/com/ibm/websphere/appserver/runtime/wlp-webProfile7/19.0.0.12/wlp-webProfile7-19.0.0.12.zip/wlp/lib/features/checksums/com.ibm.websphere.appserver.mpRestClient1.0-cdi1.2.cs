#Wed Nov 20 06:08:32 GMT 2019
lib/features/com.ibm.websphere.appserver.mpRestClient1.0-cdi1.2.mf=650f66faddfde3e0fb4aaf52d131b627
lib/com.ibm.ws.microprofile.rest.client.cdi_1.0.35.jar=db20e6ac04213d60f0b43169c7000bc6
