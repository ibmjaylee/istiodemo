#Wed Oct 02 06:05:56 BST 2019
lib/com.ibm.ws.javaee.persistence.api.2.1_1.0.33.jar=6921f5ac79e14616a0c81dff8bdf8085
dev/api/spec/com.ibm.websphere.javaee.persistence.2.1_1.0.33.jar=e538f7085209d75e66a81e81e8324624
lib/features/com.ibm.websphere.appserver.javax.persistence-2.1.mf=f8accd1dacd79498b8f1ecaca0087337
