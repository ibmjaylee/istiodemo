#Wed Nov 20 06:08:33 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.activation.1.1_1.0.35.jar=4ab6d2935dcdde99bd76319deaa195c5
dev/api/spec/com.ibm.websphere.javaee.jaxrs.2.0_1.0.35.jar=b52065c163d4f96948cf6a850942f136
dev/api/spec/com.ibm.websphere.javaee.jaxb.2.2_1.0.35.jar=8c248e6e072bb24c9bc9e6f06732f88b
lib/features/com.ibm.websphere.appserver.javax.jaxrs-2.0.mf=dda7d1b05e1152691e261655ef295140
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs20_1.0.35.jar=2bac632f1fd26b833f70cfeb9a3c2b9e
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jaxrs20_1.0-javadoc.zip=66af53c47f2e88ddfe695585200f7ec2
