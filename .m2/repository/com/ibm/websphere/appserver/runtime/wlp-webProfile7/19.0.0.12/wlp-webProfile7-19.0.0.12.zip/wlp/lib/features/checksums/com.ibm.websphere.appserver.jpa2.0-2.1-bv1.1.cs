#Wed Nov 20 06:08:33 GMT 2019
lib/com.ibm.ws.jpa.container.beanvalidation.1.1_1.0.35.jar=44e1a775a5ce64670de25672606bf9bd
lib/features/com.ibm.websphere.appserver.jpa2.0-2.1-bv1.1.mf=652195b615080e6f4d40b94d1c4b599b
