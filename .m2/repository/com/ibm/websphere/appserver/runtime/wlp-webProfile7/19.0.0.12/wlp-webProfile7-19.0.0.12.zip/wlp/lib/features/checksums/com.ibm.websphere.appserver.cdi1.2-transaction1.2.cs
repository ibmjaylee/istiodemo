#Wed Nov 20 06:08:33 GMT 2019
lib/com.ibm.ws.cdi.transaction_1.0.35.jar=3c5aaf59931ac1a8b67ec6422d7365ea
lib/features/com.ibm.websphere.appserver.cdi1.2-transaction1.2.mf=b5f40804ca3ad9ab89359f25706a73fa
