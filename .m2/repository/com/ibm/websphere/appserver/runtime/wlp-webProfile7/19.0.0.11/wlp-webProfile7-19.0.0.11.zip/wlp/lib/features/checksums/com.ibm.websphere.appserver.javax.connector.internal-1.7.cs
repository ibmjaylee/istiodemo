#Thu Oct 31 06:09:11 GMT 2019
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.7.mf=06b4b5c48be6bd5a803d37fa623c9f8d
dev/api/spec/com.ibm.websphere.javaee.connector.1.7_1.0.34.jar=f44bf1a8b16cdd3982c92a819f6d72f2
