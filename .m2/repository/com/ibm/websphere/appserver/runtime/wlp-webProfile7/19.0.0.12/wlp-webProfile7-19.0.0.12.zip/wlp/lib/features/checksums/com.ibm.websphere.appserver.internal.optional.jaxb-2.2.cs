#Wed Nov 20 06:08:34 GMT 2019
dev/api/spec/com.ibm.websphere.javaee.activation.1.1_1.0.35.jar=4ab6d2935dcdde99bd76319deaa195c5
lib/com.ibm.ws.jaxb.tools.2.2.10_1.0.35.jar=284e59fdfc3c64d44dea79f15a9ac561
dev/api/spec/com.ibm.websphere.javaee.jaxb.2.2_1.0.35.jar=8c248e6e072bb24c9bc9e6f06732f88b
lib/features/com.ibm.websphere.appserver.internal.optional.jaxb-2.2.mf=f937b7ca8ff5db711862032086f21124
lib/com.ibm.ws.org.apache.geronimo.osgi.registry.1.1_1.0.35.jar=580686cc3eb0cdda05cea29a2a6c8e31
