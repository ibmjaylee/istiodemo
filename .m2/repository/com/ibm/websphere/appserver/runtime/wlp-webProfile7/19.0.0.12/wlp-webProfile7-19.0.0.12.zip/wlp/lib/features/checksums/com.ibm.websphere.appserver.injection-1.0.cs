#Wed Nov 20 06:08:34 GMT 2019
lib/com.ibm.ws.injection_1.0.35.jar=6027513cc4df659953ec816c880dd2d2
lib/features/com.ibm.websphere.appserver.injection-1.0.mf=cce44215aed2060961900ebfbf5e8797
