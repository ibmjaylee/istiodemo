#Wed Nov 20 06:08:33 GMT 2019
lib/com.ibm.ws.ejbcontainer.jpa_1.0.35.jar=3dd174dc50d2a57faf4ad108bc02c5d9
lib/features/com.ibm.websphere.appserver.ejbliteJPA-1.0.mf=cd56e65211c35b120dd597730329c742
