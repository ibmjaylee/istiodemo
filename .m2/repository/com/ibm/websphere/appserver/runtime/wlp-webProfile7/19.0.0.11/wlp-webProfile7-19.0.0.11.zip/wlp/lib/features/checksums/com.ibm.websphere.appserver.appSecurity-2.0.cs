#Thu Oct 31 06:09:11 GMT 2019
lib/features/com.ibm.websphere.appserver.appSecurity-2.0.mf=9a98d72374f63e38b1b047854a34f4d1
lib/com.ibm.ws.security.authentication.tai_1.0.34.jar=ef05953740d418f1edf95a006bee2458
