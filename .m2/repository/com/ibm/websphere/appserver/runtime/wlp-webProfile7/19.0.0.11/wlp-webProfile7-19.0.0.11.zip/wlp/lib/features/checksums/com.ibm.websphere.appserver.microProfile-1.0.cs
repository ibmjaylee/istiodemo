#Thu Oct 31 06:09:11 GMT 2019
lib/com.ibm.ws.require.java8_1.0.34.jar=a01109427109eaee5533b667b62fdb29
lib/features/com.ibm.websphere.appserver.microProfile-1.0.mf=5b7e1f1c1eed8a17a29ecee29e2f6e97
