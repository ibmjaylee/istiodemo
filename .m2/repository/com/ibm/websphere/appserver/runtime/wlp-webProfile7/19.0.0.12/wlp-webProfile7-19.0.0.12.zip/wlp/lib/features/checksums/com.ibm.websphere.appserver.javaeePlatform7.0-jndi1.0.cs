#Wed Nov 20 06:08:33 GMT 2019
lib/features/com.ibm.websphere.appserver.javaeePlatform7.0-jndi1.0.mf=85b86589b82fad9dcc3b418b9b113430
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.35.jar=8a8f8a13819b7c703b1a7c219eceb8c7
