#Wed Oct 02 06:05:56 BST 2019
dev/api/ibm/schema/ibm-managed-bean-bnd_1_0.xsd=3b0b778a121ff7c6c28f9e72afd96488
lib/features/com.ibm.websphere.appserver.managedBeans-1.0.mf=63b4005a3403f6bfc6b94afcb598e068
dev/api/ibm/schema/ibm-managed-bean-bnd_1_1.xsd=788164a7a6ea3fb24bb6106a48a9068b
lib/com.ibm.ws.managedbeans_1.0.33.jar=7a700098aff90d0cbdecdd5490c6c930
