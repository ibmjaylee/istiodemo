#Wed Oct 02 06:05:55 BST 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.rest.client.1.0_1.0.33.jar=9db1fdd2550ef848fdb83db2baa1216d
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.rest.client-1.0.mf=2dbbe452cef5f23f86850ffe7f15ef7c
