#Thu Oct 31 06:09:10 GMT 2019
lib/features/com.ibm.websphere.appserver.jaxrsejb-2.0.mf=18088c4db8cb52a3b5cbb5ff020f23ac
lib/com.ibm.ws.jaxrs.2.0.ejb_1.0.34.jar=5a67eb9f5a528878aa2169b595ed4ca9
