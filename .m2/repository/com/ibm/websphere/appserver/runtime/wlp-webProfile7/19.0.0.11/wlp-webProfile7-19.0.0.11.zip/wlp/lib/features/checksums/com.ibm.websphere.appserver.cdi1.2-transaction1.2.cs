#Thu Oct 31 06:09:10 GMT 2019
lib/com.ibm.ws.cdi.transaction_1.0.34.jar=61ce00f5d26a2f94c6737741831e0bdc
lib/features/com.ibm.websphere.appserver.cdi1.2-transaction1.2.mf=f1d5c59fc773a621aa2c8bc9d6e70395
