#Wed Oct 02 06:05:54 BST 2019
lib/com.ibm.websphere.rest.api.discovery_1.0.33.jar=36b69e9cf839f98aca090db33ea23f53
dev/spi/ibm/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0.33.jar=71e53a813305f1d95966a0fce3c1567d
lib/features/com.ibm.websphere.appserver.autoRestHandlerApiDiscovery-1.0.mf=0f274adf92ff7b1fe83fecbabf9685ad
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0-javadoc.zip=9db8e56d0189ed2c502129c2f3f3001c
