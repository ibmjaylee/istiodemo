#Wed Oct 02 06:05:54 BST 2019
dev/api/spec/com.ibm.websphere.javaee.transaction.1.1_1.0.33.jar=840c22f6476149b0357f7e8b2ffd6fce
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=1c7511758a365464cf63518d1c88e835
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.33.jar=52692454ff59f6e14a07e250608b4992
lib/features/com.ibm.websphere.appserver.jta-1.1.mf=52cbc20c120b39317f39a58e849e0f95
