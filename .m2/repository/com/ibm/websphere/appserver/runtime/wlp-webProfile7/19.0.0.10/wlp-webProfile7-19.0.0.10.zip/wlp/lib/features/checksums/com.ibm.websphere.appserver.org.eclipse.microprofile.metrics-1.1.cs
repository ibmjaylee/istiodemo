#Wed Oct 02 06:05:55 BST 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.metrics.1.1.1_1.0.33.jar=78f41995099003c371cab151a713de0b
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.metrics-1.1.mf=3848b9b14c689237f2090ce73f6e8a76
