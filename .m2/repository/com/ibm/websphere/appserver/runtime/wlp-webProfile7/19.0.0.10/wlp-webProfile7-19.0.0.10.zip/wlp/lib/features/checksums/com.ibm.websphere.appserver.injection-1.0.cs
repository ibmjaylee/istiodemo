#Wed Oct 02 06:05:56 BST 2019
lib/features/com.ibm.websphere.appserver.injection-1.0.mf=f6992bd6fd7b44f6f70dbde7ad7053a5
lib/com.ibm.ws.injection_1.0.33.jar=6d7be76891da662ddecb50e0f8766217
