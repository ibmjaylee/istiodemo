#Thu Oct 31 06:09:11 GMT 2019
lib/com.ibm.ws.require.java8_1.0.34.jar=a01109427109eaee5533b667b62fdb29
lib/features/com.ibm.websphere.appserver.microProfile-1.3.mf=7e3721d439d6be05f2af91bdc87708dc
