#Wed Nov 20 06:08:33 GMT 2019
lib/features/com.ibm.websphere.appserver.jaxrs-2.0.mf=2b4939e4d7d71564d96e28abf46adbc1
