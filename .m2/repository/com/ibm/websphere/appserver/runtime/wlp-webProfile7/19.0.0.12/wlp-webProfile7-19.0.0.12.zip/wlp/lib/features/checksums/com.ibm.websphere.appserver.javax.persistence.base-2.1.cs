#Wed Nov 20 06:08:33 GMT 2019
lib/com.ibm.ws.javaee.persistence.2.1_1.0.35.jar=0c9979c97afd1bfdb6f54923036f0203
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.1.mf=2beaa0fb81470c9a523e71831a4e2683
