#Wed Nov 20 06:08:32 GMT 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.config.1.2.1_1.0.35.jar=a6bd22340a141be13f5a891daf823f31
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.config-1.2.mf=498d35175bf23002f81b6acb049c2b33
