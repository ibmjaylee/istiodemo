#Thu Oct 31 06:09:09 GMT 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.config.1.2.1_1.0.34.jar=13afded6ae4e69be9854d4f3836d431b
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.config-1.2.mf=ad6bc2212cf34bc1a3be9dbb50219496
