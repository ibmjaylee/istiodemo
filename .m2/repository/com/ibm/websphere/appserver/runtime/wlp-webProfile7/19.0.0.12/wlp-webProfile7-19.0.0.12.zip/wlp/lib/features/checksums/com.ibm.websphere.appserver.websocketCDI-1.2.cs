#Wed Nov 20 06:08:32 GMT 2019
lib/com.ibm.ws.wsoc.cdi.weld_1.0.35.jar=445fa2fffdbb0814f1e082f074429421
lib/features/com.ibm.websphere.appserver.websocketCDI-1.2.mf=392e389d198c7133eebf90b57b43d86d
